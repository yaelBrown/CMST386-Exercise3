CMST386-Exercise3
